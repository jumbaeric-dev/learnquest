<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'value' => 0,
    'max' => 100,
    'color' => 'primary',
    'showLabel' => true,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'value' => 0,
    'max' => 100,
    'color' => 'primary',
    'showLabel' => true,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $maxValue = max(1, (float) $max);

    $numericValue = (float) $value;

    $percentage = max(
        0,
        min(
            100,
            ($numericValue / $maxValue) * 100
        )
    );

    $allowedColors = [
        'primary',
        'cyan',
        'success',
        'warning',
        'danger',
        'reward',
    ];

    $color = in_array($color, $allowedColors, true)
        ? $color
        : 'primary';
?>

<div
    <?php echo e($attributes->class([
        'lq-progress-bar',
    ])); ?>

>
    <div
        class="lq-progress lq-progress--<?php echo e($color); ?>"
        role="progressbar"
        aria-valuenow="<?php echo e($numericValue); ?>"
        aria-valuemin="0"
        aria-valuemax="<?php echo e($max); ?>"
    >
        <span
            class="lq-progress__fill"
            style="width: <?php echo e($percentage); ?>%;"
        ></span>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($showLabel): ?>
        <div class="lq-progress-bar__labels">
            <span>
                <?php echo e(number_format($numericValue)); ?>

            </span>

            <span>
                <?php echo e(number_format($max)); ?>

            </span>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div><?php /**PATH C:\laragon\www\LearnQuest\resources\views/components/lq/progress-bar.blade.php ENDPATH**/ ?>