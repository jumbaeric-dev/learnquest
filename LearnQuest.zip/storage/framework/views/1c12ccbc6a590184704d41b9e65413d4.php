<?php if (isset($component)) { $__componentOriginala899b3b356f9c96e9e132bf56b526b2d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala899b3b356f9c96e9e132bf56b526b2d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.parent-portal.layout.app-shell','data' => ['active' => 'children']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('parent-portal.layout.app-shell'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['active' => 'children']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <div class="space-y-8">
        <div>
            <h1 class="text-3xl font-extrabold text-white">Manage children</h1>
            <p class="mt-2 text-slate-300">Create and manage your family's explorer accounts.</p>
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('parent_child_status')): ?>
        <div role="status" class="rounded-xl border border-emerald-300/20 bg-emerald-400/10 px-4 py-3 text-sm text-emerald-200">
            <?php echo e(session('parent_child_status')); ?>

        </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($generatedPin): ?>
        <section
            id="child-credentials"
            x-ref="credentials"
            class="rounded-2xl border border-cyan-300/30 bg-cyan-400/10 p-5"
            aria-live="polite"
            tabindex="-1"
            x-on:scroll-to-child-credentials.window="$nextTick(() => $refs.credentials?.scrollIntoView({ behavior: 'smooth', block: 'center' }))">
            <div class="flex flex-wrap items-start justify-between gap-4">
                <div>
                    <h2 class="font-bold text-white">Child login credentials</h2>
                    <p class="mt-1 text-sm text-slate-300">Share these details privately. The PIN is shown only here and cannot be retrieved later.</p>
                    <dl class="mt-4 grid gap-3 sm:grid-cols-2">
                        <div>
                            <dt class="text-xs uppercase tracking-wide text-slate-400">Username</dt>
                            <dd class="mt-1 font-semibold text-white"><?php echo e($generatedUsername); ?></dd>
                        </div>
                        <div>
                            <dt class="text-xs uppercase tracking-wide text-slate-400">New PIN</dt>
                            <dd class="mt-1 font-mono text-2xl font-extrabold tracking-widest text-cyan-200"><?php echo e($generatedPin); ?></dd>
                        </div>
                    </dl>
                </div>
                <button type="button" wire:click="dismissCredentials" class="rounded-lg border border-white/20 px-3 py-2 text-sm font-semibold text-white hover:bg-white/10">Dismiss</button>
            </div>
        </section>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($limitMessage): ?>
        <section role="note" class="rounded-2xl border border-amber-300/30 bg-amber-400/10 p-6">
            <h2 class="font-bold text-white">Child limit reached</h2>
            <p class="mt-1 text-sm text-amber-100"><?php echo e($limitMessage); ?></p>
            <a href="<?php echo e(route('parent.billing')); ?>" class="mt-3 inline-flex rounded-lg bg-white/10 px-3 py-2 text-sm font-semibold text-white hover:bg-white/20">See plans</a>
        </section>
        <?php else: ?>
        <section class="rounded-2xl border border-white/10 bg-white p-6 text-slate-900 shadow-xl">
            <h2 class="text-xl font-bold">Add a child</h2>
            <p class="mt-1 text-sm text-slate-600">A unique username will be suggested if you leave that field blank. A secure four-digit PIN will be generated.</p>

            <form wire:submit="createChild" class="mt-5 space-y-4">
                <div class="grid gap-4 sm:grid-cols-2">
                    <label class="block text-sm font-semibold text-slate-700">
                        First name
                        <input wire:model="first_name" type="text" maxlength="50" required autocomplete="given-name" class="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2 text-slate-900 focus:border-cyan-600 focus:outline-none focus:ring-2 focus:ring-cyan-100">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="mt-1 block text-xs text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </label>
                    <label class="block text-sm font-semibold text-slate-700">
                        Last name
                        <input wire:model="last_name" type="text" maxlength="50" autocomplete="family-name" class="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2 text-slate-900 focus:border-cyan-600 focus:outline-none focus:ring-2 focus:ring-cyan-100">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="mt-1 block text-xs text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </label>
                    <label class="block text-sm font-semibold text-slate-700">
                        Username <span class="font-normal text-slate-500">(optional)</span>
                        <input wire:model="username" type="text" maxlength="30" autocomplete="off" class="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2 text-slate-900 focus:border-cyan-600 focus:outline-none focus:ring-2 focus:ring-cyan-100">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="mt-1 block text-xs text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </label>
                    <label class="block text-sm font-semibold text-slate-700">
                        Date of birth <span class="font-normal text-slate-500">(optional)</span>
                        <input wire:model="date_of_birth" type="date" max="<?php echo e(now()->subDay()->toDateString()); ?>" class="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2 text-slate-900 focus:border-cyan-600 focus:outline-none focus:ring-2 focus:ring-cyan-100">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['date_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="mt-1 block text-xs text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </label>
                </div>
                <label class="block max-w-xs text-sm font-semibold text-slate-700">
                    Explorer avatar
                    <select wire:model="avatar" class="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2 text-slate-900">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $availableAvatars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <option value="<?php echo e($option); ?>"><?php echo e($option); ?></option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </select>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="mt-1 block text-xs text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </label>
                <button type="submit" wire:loading.attr="disabled" class="inline-flex items-center justify-center gap-2 rounded-xl bg-cyan-600 px-5 py-3 text-sm font-bold !text-white shadow-sm transition hover:bg-cyan-700 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:ring-offset-2">
                    <span wire:loading.remove wire:target="createChild">Create child account</span>
                    <span wire:loading wire:target="createChild">Creating…</span>
                </button>
            </form>
        </section>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        
        <section class="space-y-4">
            <div>
                <h2 class="text-xl font-bold text-white">Your children</h2>
                <p class="mt-1 text-sm text-slate-400">Only children connected to your parent account appear here.</p>
            </div>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <article <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'child-'.e($child->id).''; ?>wire:key="child-<?php echo e($child->id); ?>" class="rounded-2xl border border-white/10 bg-white p-5 text-slate-900 shadow-lg">
                <div class="flex flex-wrap items-center justify-between gap-4">
                    <div class="flex items-center gap-3">
                        <span class="flex h-14 w-14 items-center justify-center rounded-2xl bg-cyan-50 text-3xl"><?php echo e($child->avatar ?: '🚀'); ?></span>
                        <div>
                            <h3 class="font-bold text-slate-900"><?php echo e($child->full_name); ?></h3>
                            <p class="text-sm text-slate-600"><?php echo e($child->username); ?> · Level <?php echo e($child->level); ?> · <?php echo e(number_format($child->xp)); ?> XP</p>
                            <p class="text-xs <?php echo e($child->is_active ? 'text-emerald-700' : 'text-red-700'); ?>"><?php echo e($child->is_active ? 'Active account' : 'Inactive account'); ?></p>
                        </div>
                    </div>
                    <div class="flex flex-wrap gap-2">
                        <button type="button" wire:click="switchToChild(<?php echo e($child->id); ?>)" <?php if(!$child->is_active): echo 'disabled'; endif; ?> class="rounded-lg bg-cyan-700 px-3 py-2 text-sm font-semibold text-white hover:bg-cyan-800 disabled:cursor-not-allowed disabled:opacity-50">Switch to child</button>
                        <button type="button" wire:click="beginEdit(<?php echo e($child->id); ?>)" class="rounded-lg border border-slate-300 px-3 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50">Edit</button>
                        <button type="button" wire:click="resetChildPin(<?php echo e($child->id); ?>)" wire:confirm="Generate a new PIN? The child's existing PIN will stop working." class="rounded-lg border border-slate-300 px-3 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50">Reset PIN</button>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($child->is_active): ?>
                        <button type="button" wire:click="setChildActive(<?php echo e($child->id); ?>, false)" wire:confirm="Pause <?php echo e($child->first_name); ?>’s account? They won’t be able to sign in until you resume it." class="rounded-lg border border-slate-300 px-3 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50">Pause</button>
                        <?php else: ?>
                        <button type="button" wire:click="setChildActive(<?php echo e($child->id); ?>, true)" class="rounded-lg border border-emerald-300 px-3 py-2 text-sm font-semibold text-emerald-800 hover:bg-emerald-50">Resume</button>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <button type="button" wire:click="askToRemove(<?php echo e($child->id); ?>)" class="rounded-lg border border-red-200 px-3 py-2 text-sm font-semibold text-red-700 hover:bg-red-50">Remove</button>
                    </div>
                </div>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($editingChildId === $child->id): ?>
                <form wire:submit="saveEdit" class="mt-5 space-y-4 rounded-xl bg-slate-50 p-4">
                    <h4 class="font-bold text-slate-900">Edit explorer profile</h4>
                    <div class="grid gap-3 sm:grid-cols-2">
                        <label class="text-sm font-semibold text-slate-700">First name
                            <input wire:model="editFirstName" type="text" maxlength="50" required class="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['editFirstName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-xs text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </label>
                        <label class="text-sm font-semibold text-slate-700">Last name
                            <input wire:model="editLastName" type="text" maxlength="50" class="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['editLastName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-xs text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </label>
                        <label class="text-sm font-semibold text-slate-700">Date of birth
                            <input wire:model="editDateOfBirth" type="date" max="<?php echo e(now()->subDay()->toDateString()); ?>" class="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['editDateOfBirth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-xs text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </label>
                        <label class="text-sm font-semibold text-slate-700">Avatar
                            <select wire:model="editAvatar" class="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $availableAvatars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <option value="<?php echo e($option); ?>"><?php echo e($option); ?></option>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            </select>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['editAvatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-xs text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </label>
                    </div>
                    <div class="flex gap-2">
                        <button type="submit" class="rounded-lg bg-cyan-700 px-4 py-2 text-sm font-bold text-white">Save changes</button>
                        <button type="button" wire:click="cancelEdit" class="rounded-lg border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-700">Cancel</button>
                    </div>
                </form>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($confirmDeleteChildId === $child->id): ?>
                <div class="mt-5 rounded-xl border border-red-200 bg-red-50 p-4" role="alert">
                    <p class="font-bold text-red-900">Permanently remove <?php echo e($child->first_name); ?>?</p>
                    <p class="mt-1 text-sm text-red-800">This deletes the child's login and profile, including course and lesson progress, badges, streak history, daily challenge claims and Nova message history. This cannot be undone.</p>
                    <div class="mt-3 flex gap-2">
                        <button type="button" wire:click="removeChild" wire:loading.attr="disabled" class="rounded-lg bg-red-700 px-4 py-2 text-sm font-bold text-red hover:bg-red-800">Permanently remove</button>
                        <button type="button" wire:click="cancelRemove" class="rounded-lg border border-red-300 px-4 py-2 text-sm font-semibold text-red-800">Keep child</button>
                    </div>
                </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </article>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            <div class="rounded-2xl border border-dashed border-white/20 bg-white/5 p-8 text-center">
                <p class="text-3xl">🧑‍🚀</p>
                <h3 class="mt-3 font-bold text-white">No child accounts yet</h3>
                <p class="mt-1 text-sm text-slate-400">Use the form above to add your first explorer.</p>
            </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </section>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala899b3b356f9c96e9e132bf56b526b2d)): ?>
<?php $attributes = $__attributesOriginala899b3b356f9c96e9e132bf56b526b2d; ?>
<?php unset($__attributesOriginala899b3b356f9c96e9e132bf56b526b2d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala899b3b356f9c96e9e132bf56b526b2d)): ?>
<?php $component = $__componentOriginala899b3b356f9c96e9e132bf56b526b2d; ?>
<?php unset($__componentOriginala899b3b356f9c96e9e132bf56b526b2d); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\LearnQuest\resources\views/livewire/parent-portal/children/index.blade.php ENDPATH**/ ?>