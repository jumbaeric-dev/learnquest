<?php if (isset($component)) { $__componentOriginal8507755dcd08db580955741507bc6b99 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8507755dcd08db580955741507bc6b99 = $attributes; } ?>
<?php $component = App\View\Components\Lq\GlassCard::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lq.glass-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Lq\GlassCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['animate' => true]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>



    <?php if (isset($component)) { $__componentOriginal1884a0413a233115de9a618728cc4a6b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1884a0413a233115de9a618728cc4a6b = $attributes; } ?>
<?php $component = App\View\Components\Lq\SectionTitle::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lq.section-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Lq\SectionTitle::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>


        🎯 Daily Challenge

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1884a0413a233115de9a618728cc4a6b)): ?>
<?php $attributes = $__attributesOriginal1884a0413a233115de9a618728cc4a6b; ?>
<?php unset($__attributesOriginal1884a0413a233115de9a618728cc4a6b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1884a0413a233115de9a618728cc4a6b)): ?>
<?php $component = $__componentOriginal1884a0413a233115de9a618728cc4a6b; ?>
<?php unset($__componentOriginal1884a0413a233115de9a618728cc4a6b); ?>
<?php endif; ?>



    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($challenge): ?>


        <div class="mt-5">


            <h3 class="text-xl font-bold">

                <?php echo e($challenge['title']); ?>


            </h3>



            <p class="mt-1 text-slate-500">

                <?php echo e($challenge['description']); ?>


            </p>



            <div class="mt-5">


                <?php if (isset($component)) { $__componentOriginalcb8e0dc651f7dc2932ea919127cc10f1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb8e0dc651f7dc2932ea919127cc10f1 = $attributes; } ?>
<?php $component = App\View\Components\Lq\ProgressBar::resolve(['value' => $challenge['current'],'max' => $challenge['target']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lq.progress-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Lq\ProgressBar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['percentage' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(
                        min(
                            100,
                            ($challenge['current']
                            /
                            $challenge['target'])
                            * 100
                        )
                    )]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb8e0dc651f7dc2932ea919127cc10f1)): ?>
<?php $attributes = $__attributesOriginalcb8e0dc651f7dc2932ea919127cc10f1; ?>
<?php unset($__attributesOriginalcb8e0dc651f7dc2932ea919127cc10f1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb8e0dc651f7dc2932ea919127cc10f1)): ?>
<?php $component = $__componentOriginalcb8e0dc651f7dc2932ea919127cc10f1; ?>
<?php unset($__componentOriginalcb8e0dc651f7dc2932ea919127cc10f1); ?>
<?php endif; ?>


            </div>



            <div
                class="
                mt-4
                flex
                items-center
                justify-between
                "
            >


                <span
                    class="text-sm text-slate-500"
                >

                    ⭐
                    +<?php echo e($challenge['xpReward']); ?>

                    XP

                </span>



                <?php if (isset($component)) { $__componentOriginalffd5753d2d48917a3dd59c1d9ea70fe1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalffd5753d2d48917a3dd59c1d9ea70fe1 = $attributes; } ?>
<?php $component = App\View\Components\Lq\Button::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lq.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Lq\Button::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'startMission','disabled' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($challenge['current'] >= $challenge['target'])]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>


                    <?php echo e($challenge['buttonText']); ?>


                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalffd5753d2d48917a3dd59c1d9ea70fe1)): ?>
<?php $attributes = $__attributesOriginalffd5753d2d48917a3dd59c1d9ea70fe1; ?>
<?php unset($__attributesOriginalffd5753d2d48917a3dd59c1d9ea70fe1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalffd5753d2d48917a3dd59c1d9ea70fe1)): ?>
<?php $component = $__componentOriginalffd5753d2d48917a3dd59c1d9ea70fe1; ?>
<?php unset($__componentOriginalffd5753d2d48917a3dd59c1d9ea70fe1); ?>
<?php endif; ?>


            </div>


        </div>


    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8507755dcd08db580955741507bc6b99)): ?>
<?php $attributes = $__attributesOriginal8507755dcd08db580955741507bc6b99; ?>
<?php unset($__attributesOriginal8507755dcd08db580955741507bc6b99); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8507755dcd08db580955741507bc6b99)): ?>
<?php $component = $__componentOriginal8507755dcd08db580955741507bc6b99; ?>
<?php unset($__componentOriginal8507755dcd08db580955741507bc6b99); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\LearnQuest\resources\views/components/child/dashboard/daily-challenge.blade.php ENDPATH**/ ?>