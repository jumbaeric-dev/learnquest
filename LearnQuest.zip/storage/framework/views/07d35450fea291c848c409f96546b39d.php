<div class="space-y-4">


    <h2 class="text-xl font-bold text-gray-800">

        🧭 Explore Missions

    </h2>



    <div class="flex gap-3 overflow-x-auto pb-2">


        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>


            <button

                wire:click="selectCategory('<?php echo e($category['name']); ?>')"

                class="
                    flex items-center gap-2
                    px-4 py-3
                    rounded-2xl
                    whitespace-nowrap
                    transition
                    border
                    shadow-sm

                    <?php if($selectedCategory === $category['name']): ?>
                        bg-indigo-500
                        text-white
                    <?php else: ?>
                        bg-white/70
                        text-gray-700
                    <?php endif; ?>
                "

            >

                <span class="text-xl">

                    <?php if (isset($component)) { $__componentOriginal4ce7f8275c2c762cfadda499ac3e41e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4ce7f8275c2c762cfadda499ac3e41e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.lq.world-icon','data' => ['name' => $category['icon'] ?? null,'class' => 'h-5 w-5','fallback' => '🌍']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lq.world-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($category['icon'] ?? null),'class' => 'h-5 w-5','fallback' => '🌍']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4ce7f8275c2c762cfadda499ac3e41e3)): ?>
<?php $attributes = $__attributesOriginal4ce7f8275c2c762cfadda499ac3e41e3; ?>
<?php unset($__attributesOriginal4ce7f8275c2c762cfadda499ac3e41e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4ce7f8275c2c762cfadda499ac3e41e3)): ?>
<?php $component = $__componentOriginal4ce7f8275c2c762cfadda499ac3e41e3; ?>
<?php unset($__componentOriginal4ce7f8275c2c762cfadda499ac3e41e3); ?>
<?php endif; ?>

                </span>


                <span class="font-semibold">

                    <?php echo e($category['label'] ?? $category['name']); ?>


                </span>


            </button>


        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>


    </div>


</div><?php /**PATH C:\laragon\www\LearnQuest\resources\views/livewire/child/missions/components/mission-categories.blade.php ENDPATH**/ ?>