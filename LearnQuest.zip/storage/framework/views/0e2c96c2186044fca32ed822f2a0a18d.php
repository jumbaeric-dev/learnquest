<?php if (isset($component)) { $__componentOriginald44a78fdd8ad2f2bb19c574ee0f8552a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald44a78fdd8ad2f2bb19c574ee0f8552a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.child.layout.app-shell','data' => ['theme' => $theme,'explorer' => $explorer,'active' => 'courses']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('child.layout.app-shell'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['theme' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($theme),'explorer' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($explorer),'active' => 'courses']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>


    <?php
        $content = $activity->content ?? [];

        $options = is_array($content['options'] ?? null)
            ? $content['options']
            : [];

        $hasQuestion = ! empty($content['question']);

        $passScore = config('learnquest.activity_pass_score', 70);

        $completed = (bool) $progress?->completed;

        $correctIndex = isset($content['answer'])
            ? (int) $content['answer']
            : null;

        [$typeIcon, $typeLabel] = match ($activity->activity_type) {
            'quiz' => ['❓', 'Quiz'],
            'story' => ['📖', 'Story'],
            'project' => ['🛠️', 'Project'],
            'ai_chat' => ['🤖', 'Chat with AI'],
            'coding_challenge' => ['💻', 'Coding Challenge'],
            'video' => ['🎬', 'Video'],
            default => ['🎯', ucfirst(str_replace('_', ' ', (string) $activity->activity_type))],
        };

        $body = $content['instructions']
            ?? $content['story_text']
            ?? $content['project_description']
            ?? $content['challenge']
            ?? $content['goal']
            ?? null;
    ?>

    <?php if (isset($component)) { $__componentOriginal8b7c9816033db6798d22fa28364863e7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b7c9816033db6798d22fa28364863e7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.child.layout.section-stack','data' => ['spacing' => 'relaxed']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('child.layout.section-stack'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['spacing' => 'relaxed']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>


        
        <div>
            <?php if (isset($component)) { $__componentOriginalffd5753d2d48917a3dd59c1d9ea70fe1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalffd5753d2d48917a3dd59c1d9ea70fe1 = $attributes; } ?>
<?php $component = App\View\Components\Lq\Button::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lq.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Lq\Button::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tag' => 'a','href' => ''.e(route('learn.lesson', $activity->lesson)).'','variant' => 'secondary','size' => 'sm']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

                ← Back to Lesson
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalffd5753d2d48917a3dd59c1d9ea70fe1)): ?>
<?php $attributes = $__attributesOriginalffd5753d2d48917a3dd59c1d9ea70fe1; ?>
<?php unset($__attributesOriginalffd5753d2d48917a3dd59c1d9ea70fe1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalffd5753d2d48917a3dd59c1d9ea70fe1)): ?>
<?php $component = $__componentOriginalffd5753d2d48917a3dd59c1d9ea70fe1; ?>
<?php unset($__componentOriginalffd5753d2d48917a3dd59c1d9ea70fe1); ?>
<?php endif; ?>
        </div>


        
        <?php if (isset($component)) { $__componentOriginal8507755dcd08db580955741507bc6b99 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8507755dcd08db580955741507bc6b99 = $attributes; } ?>
<?php $component = App\View\Components\Lq\GlassCard::resolve(['padding' => 'lg'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lq.glass-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Lq\GlassCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'hero','class' => 'lq-course-hero']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

            <div class="lq-course-hero__inner">

                <div class="lq-course-hero__main">

                    <div class="lq-course-hero__icon" aria-hidden="true">
                        <?php echo e($typeIcon); ?>

                    </div>

                    <div class="lq-course-hero__body">

                        <div class="lq-course-hero__tags">

                            <span class="lq-course-hero__tag">
                                📘 <?php echo e($activity->lesson->title); ?>

                            </span>

                            <span class="lq-course-hero__tag">
                                <?php echo e($typeIcon); ?> <?php echo e($typeLabel); ?>

                            </span>

                        </div>

                        <h1 class="lq-course-hero__title">
                            <?php echo e($activity->title); ?>

                        </h1>

                    </div>

                </div>


                
                <div class="lq-course-hero__progress">

                    <div class="lq-course-hero__progress-head">
                        <span class="lq-course-hero__progress-label">
                            Reward
                        </span>

                        <strong class="lq-course-hero__progress-value">
                            ⭐ <?php echo e($activity->xp_reward); ?> XP
                        </strong>
                    </div>

                    <p class="lq-course-hero__meta">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($completed): ?>
                            ✓ Completed — great job!
                        <?php elseif($hasQuestion): ?>
                            Score <?php echo e($passScore); ?>% or more to earn it.
                        <?php else: ?>
                            Finish the activity to earn it.
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </p>

                </div>

            </div>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8507755dcd08db580955741507bc6b99)): ?>
<?php $attributes = $__attributesOriginal8507755dcd08db580955741507bc6b99; ?>
<?php unset($__attributesOriginal8507755dcd08db580955741507bc6b99); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8507755dcd08db580955741507bc6b99)): ?>
<?php $component = $__componentOriginal8507755dcd08db580955741507bc6b99; ?>
<?php unset($__componentOriginal8507755dcd08db580955741507bc6b99); ?>
<?php endif; ?>


        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($hasQuestion): ?>

            <?php if (isset($component)) { $__componentOriginal8507755dcd08db580955741507bc6b99 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8507755dcd08db580955741507bc6b99 = $attributes; } ?>
<?php $component = App\View\Components\Lq\GlassCard::resolve(['padding' => 'lg'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lq.glass-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Lq\GlassCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'space-y-6']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>


                <div class="space-y-2">
                    <?php if (isset($component)) { $__componentOriginaleec744ad5116c721f48141438b9836a9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaleec744ad5116c721f48141438b9836a9 = $attributes; } ?>
<?php $component = App\View\Components\Lq\Badge::resolve(['variant' => 'primary'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lq.badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Lq\Badge::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => 'sm']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

                        Question
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaleec744ad5116c721f48141438b9836a9)): ?>
<?php $attributes = $__attributesOriginaleec744ad5116c721f48141438b9836a9; ?>
<?php unset($__attributesOriginaleec744ad5116c721f48141438b9836a9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaleec744ad5116c721f48141438b9836a9)): ?>
<?php $component = $__componentOriginaleec744ad5116c721f48141438b9836a9; ?>
<?php unset($__componentOriginaleec744ad5116c721f48141438b9836a9); ?>
<?php endif; ?>

                    <h2 class="text-2xl font-extrabold leading-snug text-slate-800">
                        <?php echo e($content['question']); ?>

                    </h2>
                </div>


                
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(! $submitted || $completed): ?>

                    <div class="space-y-3">

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>

                            <?php
                                $label = is_array($option)
                                    ? ($option['option'] ?? $option['label'] ?? $option['text'] ?? '')
                                    : $option;

                                $isCorrect = $submitted && $correctIndex === $index;
                            ?>

                            <button
                                type="button"
                                <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'option-'.e($index).''; ?>wire:key="option-<?php echo e($index); ?>"
                                wire:click="submitOption(<?php echo e($index); ?>)"
                                wire:loading.attr="disabled"
                                wire:target="submitOption"
                                <?php if($submitted): echo 'disabled'; endif; ?>
                                class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                    'group flex w-full items-center gap-4 rounded-2xl border-2 p-4 text-left font-semibold transition',
                                    'cursor-pointer border-slate-200 bg-white text-slate-700 hover:-translate-y-0.5 hover:border-[color:var(--lq-theme-primary)] hover:shadow-md' => ! $submitted,
                                    'border-emerald-400 bg-emerald-50 text-emerald-800' => $isCorrect,
                                    'border-slate-200 bg-white text-slate-500 opacity-60' => $submitted && ! $isCorrect,
                                ]); ?>"
                            >

                                <span
                                    class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                        'flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-sm font-extrabold transition',
                                        'bg-slate-100 text-slate-500 group-hover:bg-[color:var(--lq-theme-primary)] group-hover:text-white' => ! $submitted,
                                        'bg-emerald-500 text-white' => $isCorrect,
                                        'bg-slate-100 text-slate-400' => $submitted && ! $isCorrect,
                                    ]); ?>"
                                >
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isCorrect): ?>
                                        ✓
                                    <?php else: ?>
                                        <?php echo e(chr(65 + $loop->index)); ?>

                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </span>

                                <span class="flex-1">
                                    <?php echo e($label); ?>

                                </span>

                            </button>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

                    </div>

                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8507755dcd08db580955741507bc6b99)): ?>
<?php $attributes = $__attributesOriginal8507755dcd08db580955741507bc6b99; ?>
<?php unset($__attributesOriginal8507755dcd08db580955741507bc6b99); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8507755dcd08db580955741507bc6b99)): ?>
<?php $component = $__componentOriginal8507755dcd08db580955741507bc6b99; ?>
<?php unset($__componentOriginal8507755dcd08db580955741507bc6b99); ?>
<?php endif; ?>

        <?php else: ?>

            
            <?php if (isset($component)) { $__componentOriginal8507755dcd08db580955741507bc6b99 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8507755dcd08db580955741507bc6b99 = $attributes; } ?>
<?php $component = App\View\Components\Lq\GlassCard::resolve(['padding' => 'lg'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lq.glass-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Lq\GlassCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'space-y-4']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>


                <?php if (isset($component)) { $__componentOriginaleec744ad5116c721f48141438b9836a9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaleec744ad5116c721f48141438b9836a9 = $attributes; } ?>
<?php $component = App\View\Components\Lq\Badge::resolve(['variant' => 'primary'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lq.badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Lq\Badge::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => 'sm']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

                    <?php echo e($typeIcon); ?> <?php echo e($typeLabel); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaleec744ad5116c721f48141438b9836a9)): ?>
<?php $attributes = $__attributesOriginaleec744ad5116c721f48141438b9836a9; ?>
<?php unset($__attributesOriginaleec744ad5116c721f48141438b9836a9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaleec744ad5116c721f48141438b9836a9)): ?>
<?php $component = $__componentOriginaleec744ad5116c721f48141438b9836a9; ?>
<?php unset($__componentOriginaleec744ad5116c721f48141438b9836a9); ?>
<?php endif; ?>

                <p class="text-lg leading-relaxed text-slate-700">
                    <?php echo e($body ?? 'Complete this activity to continue your learning journey.'); ?>

                </p>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(! empty($content['difficulty'])): ?>
                    <?php if (isset($component)) { $__componentOriginaleec744ad5116c721f48141438b9836a9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaleec744ad5116c721f48141438b9836a9 = $attributes; } ?>
<?php $component = App\View\Components\Lq\Badge::resolve(['variant' => 'warning'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lq.badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Lq\Badge::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => 'sm']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

                        Difficulty: <?php echo e(ucfirst($content['difficulty'])); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaleec744ad5116c721f48141438b9836a9)): ?>
<?php $attributes = $__attributesOriginaleec744ad5116c721f48141438b9836a9; ?>
<?php unset($__attributesOriginaleec744ad5116c721f48141438b9836a9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaleec744ad5116c721f48141438b9836a9)): ?>
<?php $component = $__componentOriginaleec744ad5116c721f48141438b9836a9; ?>
<?php unset($__componentOriginaleec744ad5116c721f48141438b9836a9); ?>
<?php endif; ?>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(! $submitted): ?>
                    <div class="pt-2">
                        <?php if (isset($component)) { $__componentOriginalffd5753d2d48917a3dd59c1d9ea70fe1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalffd5753d2d48917a3dd59c1d9ea70fe1 = $attributes; } ?>
<?php $component = App\View\Components\Lq\Button::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lq.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Lq\Button::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'button','wire:click' => 'complete','wire:loading.attr' => 'disabled','wire:target' => 'complete','variant' => 'primary']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

                            ✅ Complete Activity
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalffd5753d2d48917a3dd59c1d9ea70fe1)): ?>
<?php $attributes = $__attributesOriginalffd5753d2d48917a3dd59c1d9ea70fe1; ?>
<?php unset($__attributesOriginalffd5753d2d48917a3dd59c1d9ea70fe1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalffd5753d2d48917a3dd59c1d9ea70fe1)): ?>
<?php $component = $__componentOriginalffd5753d2d48917a3dd59c1d9ea70fe1; ?>
<?php unset($__componentOriginalffd5753d2d48917a3dd59c1d9ea70fe1); ?>
<?php endif; ?>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8507755dcd08db580955741507bc6b99)): ?>
<?php $attributes = $__attributesOriginal8507755dcd08db580955741507bc6b99; ?>
<?php unset($__attributesOriginal8507755dcd08db580955741507bc6b99); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8507755dcd08db580955741507bc6b99)): ?>
<?php $component = $__componentOriginal8507755dcd08db580955741507bc6b99; ?>
<?php unset($__componentOriginal8507755dcd08db580955741507bc6b99); ?>
<?php endif; ?>

        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($submitted): ?>

            <?php if (isset($component)) { $__componentOriginal8507755dcd08db580955741507bc6b99 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8507755dcd08db580955741507bc6b99 = $attributes; } ?>
<?php $component = App\View\Components\Lq\GlassCard::resolve(['padding' => 'lg'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lq.glass-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Lq\GlassCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>


                <div class="mx-auto max-w-md space-y-5 text-center">

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($completed): ?>

                        <div class="text-6xl">🎉</div>

                        <h2 class="text-2xl font-extrabold text-slate-800">
                            Activity Complete!
                        </h2>

                        <div class="grid grid-cols-2 gap-4">

                            <?php if (isset($component)) { $__componentOriginal3841443320f7ee1c30538bd0ffefa80f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3841443320f7ee1c30538bd0ffefa80f = $attributes; } ?>
<?php $component = App\View\Components\Lq\StatChip::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lq.stat-chip'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Lq\StatChip::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => '🎯','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(($progress->score ?? 0) . '%'),'label' => 'Score','variant' => 'success']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3841443320f7ee1c30538bd0ffefa80f)): ?>
<?php $attributes = $__attributesOriginal3841443320f7ee1c30538bd0ffefa80f; ?>
<?php unset($__attributesOriginal3841443320f7ee1c30538bd0ffefa80f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3841443320f7ee1c30538bd0ffefa80f)): ?>
<?php $component = $__componentOriginal3841443320f7ee1c30538bd0ffefa80f; ?>
<?php unset($__componentOriginal3841443320f7ee1c30538bd0ffefa80f); ?>
<?php endif; ?>

                            <?php if (isset($component)) { $__componentOriginal3841443320f7ee1c30538bd0ffefa80f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3841443320f7ee1c30538bd0ffefa80f = $attributes; } ?>
<?php $component = App\View\Components\Lq\StatChip::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lq.stat-chip'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Lq\StatChip::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => '⭐','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(($progress->xp_earned ?? 0) . ' XP'),'label' => 'XP Earned','variant' => 'reward']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3841443320f7ee1c30538bd0ffefa80f)): ?>
<?php $attributes = $__attributesOriginal3841443320f7ee1c30538bd0ffefa80f; ?>
<?php unset($__attributesOriginal3841443320f7ee1c30538bd0ffefa80f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3841443320f7ee1c30538bd0ffefa80f)): ?>
<?php $component = $__componentOriginal3841443320f7ee1c30538bd0ffefa80f; ?>
<?php unset($__componentOriginal3841443320f7ee1c30538bd0ffefa80f); ?>
<?php endif; ?>

                        </div>

                        <?php if (isset($component)) { $__componentOriginalffd5753d2d48917a3dd59c1d9ea70fe1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalffd5753d2d48917a3dd59c1d9ea70fe1 = $attributes; } ?>
<?php $component = App\View\Components\Lq\Button::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lq.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Lq\Button::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tag' => 'a','href' => ''.e(route('learn.lesson', $activity->lesson)).'','variant' => 'primary']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

                            ← Back to Lesson
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalffd5753d2d48917a3dd59c1d9ea70fe1)): ?>
<?php $attributes = $__attributesOriginalffd5753d2d48917a3dd59c1d9ea70fe1; ?>
<?php unset($__attributesOriginalffd5753d2d48917a3dd59c1d9ea70fe1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalffd5753d2d48917a3dd59c1d9ea70fe1)): ?>
<?php $component = $__componentOriginalffd5753d2d48917a3dd59c1d9ea70fe1; ?>
<?php unset($__componentOriginalffd5753d2d48917a3dd59c1d9ea70fe1); ?>
<?php endif; ?>

                    <?php else: ?>

                        <div class="text-6xl">🚀</div>

                        <h2 class="text-2xl font-extrabold text-slate-800">
                            Keep Exploring!
                        </h2>

                        <div class="mx-auto max-w-[12rem]">
                            <?php if (isset($component)) { $__componentOriginal3841443320f7ee1c30538bd0ffefa80f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3841443320f7ee1c30538bd0ffefa80f = $attributes; } ?>
<?php $component = App\View\Components\Lq\StatChip::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lq.stat-chip'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Lq\StatChip::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => '🎯','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(($progress?->score ?? $score ?? 0) . '%'),'label' => 'Your Score','variant' => 'warning']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3841443320f7ee1c30538bd0ffefa80f)): ?>
<?php $attributes = $__attributesOriginal3841443320f7ee1c30538bd0ffefa80f; ?>
<?php unset($__attributesOriginal3841443320f7ee1c30538bd0ffefa80f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3841443320f7ee1c30538bd0ffefa80f)): ?>
<?php $component = $__componentOriginal3841443320f7ee1c30538bd0ffefa80f; ?>
<?php unset($__componentOriginal3841443320f7ee1c30538bd0ffefa80f); ?>
<?php endif; ?>
                        </div>

                        <p class="text-slate-600">
                            You need <?php echo e($passScore); ?>% to complete this activity.
                            You can do it — give it another go!
                        </p>

                        <?php if (isset($component)) { $__componentOriginalffd5753d2d48917a3dd59c1d9ea70fe1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalffd5753d2d48917a3dd59c1d9ea70fe1 = $attributes; } ?>
<?php $component = App\View\Components\Lq\Button::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lq.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Lq\Button::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'button','wire:click' => 'retry','variant' => 'primary']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

                            🔄 Try Again
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalffd5753d2d48917a3dd59c1d9ea70fe1)): ?>
<?php $attributes = $__attributesOriginalffd5753d2d48917a3dd59c1d9ea70fe1; ?>
<?php unset($__attributesOriginalffd5753d2d48917a3dd59c1d9ea70fe1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalffd5753d2d48917a3dd59c1d9ea70fe1)): ?>
<?php $component = $__componentOriginalffd5753d2d48917a3dd59c1d9ea70fe1; ?>
<?php unset($__componentOriginalffd5753d2d48917a3dd59c1d9ea70fe1); ?>
<?php endif; ?>

                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                </div>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8507755dcd08db580955741507bc6b99)): ?>
<?php $attributes = $__attributesOriginal8507755dcd08db580955741507bc6b99; ?>
<?php unset($__attributesOriginal8507755dcd08db580955741507bc6b99); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8507755dcd08db580955741507bc6b99)): ?>
<?php $component = $__componentOriginal8507755dcd08db580955741507bc6b99; ?>
<?php unset($__componentOriginal8507755dcd08db580955741507bc6b99); ?>
<?php endif; ?>

        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b7c9816033db6798d22fa28364863e7)): ?>
<?php $attributes = $__attributesOriginal8b7c9816033db6798d22fa28364863e7; ?>
<?php unset($__attributesOriginal8b7c9816033db6798d22fa28364863e7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b7c9816033db6798d22fa28364863e7)): ?>
<?php $component = $__componentOriginal8b7c9816033db6798d22fa28364863e7; ?>
<?php unset($__componentOriginal8b7c9816033db6798d22fa28364863e7); ?>
<?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald44a78fdd8ad2f2bb19c574ee0f8552a)): ?>
<?php $attributes = $__attributesOriginald44a78fdd8ad2f2bb19c574ee0f8552a; ?>
<?php unset($__attributesOriginald44a78fdd8ad2f2bb19c574ee0f8552a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald44a78fdd8ad2f2bb19c574ee0f8552a)): ?>
<?php $component = $__componentOriginald44a78fdd8ad2f2bb19c574ee0f8552a; ?>
<?php unset($__componentOriginald44a78fdd8ad2f2bb19c574ee0f8552a); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\LearnQuest\resources\views/livewire/child/learning/activity.blade.php ENDPATH**/ ?>