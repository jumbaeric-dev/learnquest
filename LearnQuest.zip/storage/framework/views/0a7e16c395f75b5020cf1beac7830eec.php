<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'spacing' => 'normal',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'spacing' => 'normal',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $spacingClasses = match ($spacing) {
        'tight' => 'space-y-4',
        'normal' => 'space-y-6',
        'relaxed' => 'space-y-8',
        'loose' => 'space-y-10',
        default => 'space-y-6',
    };
?>

<div <?php echo e($attributes->merge([
    'class' => $spacingClasses,
])); ?>>
    <?php echo e($slot); ?>

</div><?php /**PATH C:\laragon\www\LearnQuest\resources\views/components/child/layout/section-stack.blade.php ENDPATH**/ ?>