<div class="space-y-6">

    <div class="px-1">

        <h2 class="text-2xl font-black tracking-tight text-white">
            🗺️ Your Adventure
        </h2>

        <p class="mt-1 text-sm text-white/70">
            Keep exploring to unlock the galaxy.
        </p>

    </div>

    <div class="relative">

        
        <div
            class="absolute left-7 top-8 bottom-8
                   w-1 rounded-full
                   bg-white/30">
        </div>

        <div class="relative space-y-6">

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $nodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $node): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>

            <div
                <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'adventure-node-'.e($node['id']).''; ?>wire:key="adventure-node-<?php echo e($node['id']); ?>"
                class="relative flex items-start gap-4">

                
                <button
                    type="button"
                    wire:click="startCourse(<?php echo e($node['id']); ?>)"
                    <?php if($node['status']==='locked' ): echo 'disabled'; endif; ?>
                    class="relative z-10
       flex h-14 w-14 shrink-0
       items-center justify-center
       rounded-full
       border-4 border-white
       bg-white
       text-2xl
       shadow-xl
       transition-all
       duration-300
       <?php echo e($node['status'] === 'current'
            ? 'scale-110 ring-4 ring-cyan-300/40'
            : ''); ?>

       <?php echo e($node['status'] === 'locked'
            ? 'cursor-not-allowed opacity-50 grayscale'
            : 'hover:scale-110 active:scale-95'); ?>">
                    <?php if (isset($component)) { $__componentOriginal4ce7f8275c2c762cfadda499ac3e41e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4ce7f8275c2c762cfadda499ac3e41e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.lq.world-icon','data' => ['name' => $node['icon'] ?? null,'class' => 'h-8 w-8','fallback' => '📘']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lq.world-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($node['icon'] ?? null),'class' => 'h-8 w-8','fallback' => '📘']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4ce7f8275c2c762cfadda499ac3e41e3)): ?>
<?php $attributes = $__attributesOriginal4ce7f8275c2c762cfadda499ac3e41e3; ?>
<?php unset($__attributesOriginal4ce7f8275c2c762cfadda499ac3e41e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4ce7f8275c2c762cfadda499ac3e41e3)): ?>
<?php $component = $__componentOriginal4ce7f8275c2c762cfadda499ac3e41e3; ?>
<?php unset($__componentOriginal4ce7f8275c2c762cfadda499ac3e41e3); ?>
<?php endif; ?>
                </button>

                
                <div class="min-w-0 flex-1">

                    <div
                        class="<?php echo \Illuminate\Support\Arr::toCssClasses([ 'rounded-3xl p-4 backdrop-blur-xl transition' , 'border border-white/70 bg-white/90 shadow-xl'=> $node['status'] !== 'current',

                        'border-2 border-cyan-300 bg-white shadow-2xl shadow-cyan-500/20'
                        => $node['status'] === 'current',
                        ]); ?>"
                        >

                        <div class="flex items-start justify-between gap-3">

                            <div>

                                <h3 class="text-base font-bold text-slate-900">
                                    <?php echo e($node['title']); ?>

                                </h3>

                                <p class="mt-1 text-sm leading-relaxed text-slate-600">
                                    <?php echo e($node['description']); ?>

                                </p>

                            </div>

                            <span
                                class="shrink-0
                                           rounded-full
                                           bg-amber-100
                                           px-2.5 py-1
                                           text-xs font-semibold
                                           text-amber-700">
                                +<?php echo e($node['xp']); ?> XP
                            </span>

                        </div>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($node['status'] === 'completed'): ?>

                        <div class="mt-3 text-xs font-semibold text-emerald-600">
                            ✓ Completed
                        </div>

                        <?php elseif($node['status'] === 'current'): ?>

                        <div class="mt-3">

                            <?php if (isset($component)) { $__componentOriginalffd5753d2d48917a3dd59c1d9ea70fe1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalffd5753d2d48917a3dd59c1d9ea70fe1 = $attributes; } ?>
<?php $component = App\View\Components\Lq\Button::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lq.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Lq\Button::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'button','wire:click' => 'startCourse('.e($node['id']).')']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

                                🚀 Start Adventure
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalffd5753d2d48917a3dd59c1d9ea70fe1)): ?>
<?php $attributes = $__attributesOriginalffd5753d2d48917a3dd59c1d9ea70fe1; ?>
<?php unset($__attributesOriginalffd5753d2d48917a3dd59c1d9ea70fe1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalffd5753d2d48917a3dd59c1d9ea70fe1)): ?>
<?php $component = $__componentOriginalffd5753d2d48917a3dd59c1d9ea70fe1; ?>
<?php unset($__componentOriginalffd5753d2d48917a3dd59c1d9ea70fe1); ?>
<?php endif; ?>

                        </div>

                        <?php elseif($node['status'] === 'locked'): ?>

                        <div class="mt-3 text-xs font-semibold text-slate-400">
                            🔒 Complete the previous adventure
                        </div>

                        <?php elseif($node['status'] === 'reward'): ?>

                        <div class="mt-3 text-xs font-semibold text-purple-600">
                            🏆 Special Reward
                        </div>

                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    </div>

                </div>

            </div>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

        </div>

    </div>

</div><?php /**PATH C:\laragon\www\LearnQuest\resources\views/livewire/child/worlds/components/adventure-path.blade.php ENDPATH**/ ?>