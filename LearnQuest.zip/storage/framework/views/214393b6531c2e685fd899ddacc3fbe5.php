<?php if (isset($component)) { $__componentOriginal8507755dcd08db580955741507bc6b99 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8507755dcd08db580955741507bc6b99 = $attributes; } ?>
<?php $component = App\View\Components\Lq\GlassCard::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lq.glass-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Lq\GlassCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => '
        transition
        duration-300
        hover:-translate-y-2
        hover:shadow-2xl
    ']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>


    <div class="space-y-4">


        
        <div class="text-4xl">

            <?php if (isset($component)) { $__componentOriginal4ce7f8275c2c762cfadda499ac3e41e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4ce7f8275c2c762cfadda499ac3e41e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.lq.world-icon','data' => ['name' => $mission['icon'] ?? null,'class' => 'h-10 w-10','fallback' => '🚀']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lq.world-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($mission['icon'] ?? null),'class' => 'h-10 w-10','fallback' => '🚀']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4ce7f8275c2c762cfadda499ac3e41e3)): ?>
<?php $attributes = $__attributesOriginal4ce7f8275c2c762cfadda499ac3e41e3; ?>
<?php unset($__attributesOriginal4ce7f8275c2c762cfadda499ac3e41e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4ce7f8275c2c762cfadda499ac3e41e3)): ?>
<?php $component = $__componentOriginal4ce7f8275c2c762cfadda499ac3e41e3; ?>
<?php unset($__componentOriginal4ce7f8275c2c762cfadda499ac3e41e3); ?>
<?php endif; ?>

        </div>



        
        <div>

            <h3 class="text-xl font-bold text-gray-800">

                <?php echo e($mission['title']); ?>


            </h3>


            <p class="text-sm text-indigo-600">

                <?php echo e($mission['category']); ?>


            </p>

        </div>




        
        <p class="text-gray-600 text-sm">

            <?php echo e($mission['description']); ?>


        </p>




        
        <div class="flex flex-wrap gap-2">


            <?php if (isset($component)) { $__componentOriginal3841443320f7ee1c30538bd0ffefa80f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3841443320f7ee1c30538bd0ffefa80f = $attributes; } ?>
<?php $component = App\View\Components\Lq\StatChip::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lq.stat-chip'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Lq\StatChip::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => '⭐','label' => 'XP','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($mission['xp'])]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3841443320f7ee1c30538bd0ffefa80f)): ?>
<?php $attributes = $__attributesOriginal3841443320f7ee1c30538bd0ffefa80f; ?>
<?php unset($__attributesOriginal3841443320f7ee1c30538bd0ffefa80f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3841443320f7ee1c30538bd0ffefa80f)): ?>
<?php $component = $__componentOriginal3841443320f7ee1c30538bd0ffefa80f; ?>
<?php unset($__componentOriginal3841443320f7ee1c30538bd0ffefa80f); ?>
<?php endif; ?>


            <?php if (isset($component)) { $__componentOriginal3841443320f7ee1c30538bd0ffefa80f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3841443320f7ee1c30538bd0ffefa80f = $attributes; } ?>
<?php $component = App\View\Components\Lq\StatChip::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lq.stat-chip'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Lq\StatChip::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => '⏱','label' => 'Time','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($mission['time'])]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3841443320f7ee1c30538bd0ffefa80f)): ?>
<?php $attributes = $__attributesOriginal3841443320f7ee1c30538bd0ffefa80f; ?>
<?php unset($__attributesOriginal3841443320f7ee1c30538bd0ffefa80f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3841443320f7ee1c30538bd0ffefa80f)): ?>
<?php $component = $__componentOriginal3841443320f7ee1c30538bd0ffefa80f; ?>
<?php unset($__componentOriginal3841443320f7ee1c30538bd0ffefa80f); ?>
<?php endif; ?>


        </div>




        
        <?php if (isset($component)) { $__componentOriginalffd5753d2d48917a3dd59c1d9ea70fe1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalffd5753d2d48917a3dd59c1d9ea70fe1 = $attributes; } ?>
<?php $component = App\View\Components\Lq\Button::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lq.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Lq\Button::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'startMission']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>


            🚀 Start

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalffd5753d2d48917a3dd59c1d9ea70fe1)): ?>
<?php $attributes = $__attributesOriginalffd5753d2d48917a3dd59c1d9ea70fe1; ?>
<?php unset($__attributesOriginalffd5753d2d48917a3dd59c1d9ea70fe1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalffd5753d2d48917a3dd59c1d9ea70fe1)): ?>
<?php $component = $__componentOriginalffd5753d2d48917a3dd59c1d9ea70fe1; ?>
<?php unset($__componentOriginalffd5753d2d48917a3dd59c1d9ea70fe1); ?>
<?php endif; ?>



    </div>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8507755dcd08db580955741507bc6b99)): ?>
<?php $attributes = $__attributesOriginal8507755dcd08db580955741507bc6b99; ?>
<?php unset($__attributesOriginal8507755dcd08db580955741507bc6b99); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8507755dcd08db580955741507bc6b99)): ?>
<?php $component = $__componentOriginal8507755dcd08db580955741507bc6b99; ?>
<?php unset($__componentOriginal8507755dcd08db580955741507bc6b99); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\LearnQuest\resources\views/livewire/child/missions/components/mission-card.blade.php ENDPATH**/ ?>