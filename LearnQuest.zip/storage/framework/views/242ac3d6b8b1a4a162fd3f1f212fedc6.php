<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'active' => 'dashboard',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'active' => 'dashboard',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<aside
    id="child-navigation"
    class="lq-sidebar"
    :class="{ 'is-mobile-open': mobileMenuOpen }"
    aria-label="LearnQuest navigation"
>

    
    <div class="lq-brand">

        <div
            class="lq-brand-mark"
            aria-hidden="true"
        >
            🚀
        </div>

        <div class="lq-brand-name">
            Learn<span>Quest</span>
        </div>

    </div>


    
    <nav
        class="lq-sidebar-nav"
        aria-label="Main navigation"
    >

        <a
            href="<?php echo e(route('child.dashboard')); ?>"
            @click="mobileMenuOpen = false"
            class="lq-nav-link <?php echo e($active === 'dashboard' ? 'is-active' : ''); ?>"
            <?php if($active === 'dashboard'): ?>
                aria-current="page"
            <?php endif; ?>
        >
            <span
                class="lq-nav-icon"
                aria-hidden="true"
            >
                🌌
            </span>

            <span>
                My Universe
            </span>
        </a>


        <a
            href="<?php echo e(route('child.explore')); ?>"
            @click="mobileMenuOpen = false"
            class="lq-nav-link <?php echo e($active === 'explore' ? 'is-active' : ''); ?>"
            <?php if($active === 'explore'): ?>
                aria-current="page"
            <?php endif; ?>
        >
            <span
                class="lq-nav-icon"
                aria-hidden="true"
            >
                🧭
            </span>

            <span>
                Explorer
            </span>
        </a>


        <a
            href="<?php echo e(route('child.explore', ['section' => 'worlds'])); ?>#learning-worlds"
            @click="mobileMenuOpen = false"
            class="lq-nav-link <?php echo e($active === 'worlds' ? 'is-active' : ''); ?>"
            <?php if($active === 'worlds'): ?>
                aria-current="page"
            <?php endif; ?>
        >
            <span
                class="lq-nav-icon"
                aria-hidden="true"
            >
                🌍
            </span>

            <span>
                Worlds
            </span>
        </a>


        <a
            href="<?php echo e(route('child.missions')); ?>"
            @click="mobileMenuOpen = false"
            class="lq-nav-link <?php echo e($active === 'courses' ? 'is-active' : ''); ?>"
            <?php if($active === 'courses'): ?>
                aria-current="page"
            <?php endif; ?>
        >
            <span
                class="lq-nav-icon"
                aria-hidden="true"
            >
                📚
            </span>

            <span>
                Courses
            </span>
        </a>

    </nav>


    
    <div class="lq-sidebar-bottom">

        <?php if (isset($component)) { $__componentOriginal8507755dcd08db580955741507bc6b99 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8507755dcd08db580955741507bc6b99 = $attributes; } ?>
<?php $component = App\View\Components\Lq\GlassCard::resolve(['padding' => 'sm'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lq.glass-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Lq\GlassCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'lq-sidebar-nova']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>


            <div class="lq-row">

                <div class="lq-nova-avatar">
                    🤖
                </div>

                <div class="lq-grow">

                    <div class="lq-card-title">
                        Nova
                    </div>

                    <div class="lq-card-meta">
                        Ready to help
                    </div>

                </div>

            </div>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8507755dcd08db580955741507bc6b99)): ?>
<?php $attributes = $__attributesOriginal8507755dcd08db580955741507bc6b99; ?>
<?php unset($__attributesOriginal8507755dcd08db580955741507bc6b99); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8507755dcd08db580955741507bc6b99)): ?>
<?php $component = $__componentOriginal8507755dcd08db580955741507bc6b99; ?>
<?php unset($__componentOriginal8507755dcd08db580955741507bc6b99); ?>
<?php endif; ?>

    </div>

</aside><?php /**PATH C:\laragon\www\LearnQuest\resources\views/components/child/layout/sidebar.blade.php ENDPATH**/ ?>