<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'icon' => '🌎',
    'title',
    'description' => null,
    'progress' => 0,
    'xp' => 0,
    'badge' => null,
    'locked' => false,
    'showAction' => true,
    'gradient' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'icon' => '🌎',
    'title',
    'description' => null,
    'progress' => 0,
    'xp' => 0,
    'badge' => null,
    'locked' => false,
    'showAction' => true,
    'gradient' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $progress = max(0, min(100, (float) $progress));
?>

<article
    <?php echo e($attributes->class([
        'lq-world-tile',
        'lq-world-tile--locked' => $locked,
    ])); ?>

>
    
    <div class="lq-world-tile__hero">

        <div class="lq-world-tile__icon">
            <?php if (isset($component)) { $__componentOriginal4ce7f8275c2c762cfadda499ac3e41e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4ce7f8275c2c762cfadda499ac3e41e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.lq.world-icon','data' => ['name' => $icon,'class' => 'h-16 w-16']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lq.world-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($icon),'class' => 'h-16 w-16']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4ce7f8275c2c762cfadda499ac3e41e3)): ?>
<?php $attributes = $__attributesOriginal4ce7f8275c2c762cfadda499ac3e41e3; ?>
<?php unset($__attributesOriginal4ce7f8275c2c762cfadda499ac3e41e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4ce7f8275c2c762cfadda499ac3e41e3)): ?>
<?php $component = $__componentOriginal4ce7f8275c2c762cfadda499ac3e41e3; ?>
<?php unset($__componentOriginal4ce7f8275c2c762cfadda499ac3e41e3); ?>
<?php endif; ?>
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($badge): ?>
            <div class="absolute right-3 top-3">
                <?php if (isset($component)) { $__componentOriginaleec744ad5116c721f48141438b9836a9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaleec744ad5116c721f48141438b9836a9 = $attributes; } ?>
<?php $component = App\View\Components\Lq\Badge::resolve(['variant' => 'achievement'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lq.badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Lq\Badge::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

                    <?php echo e($badge); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaleec744ad5116c721f48141438b9836a9)): ?>
<?php $attributes = $__attributesOriginaleec744ad5116c721f48141438b9836a9; ?>
<?php unset($__attributesOriginaleec744ad5116c721f48141438b9836a9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaleec744ad5116c721f48141438b9836a9)): ?>
<?php $component = $__componentOriginaleec744ad5116c721f48141438b9836a9; ?>
<?php unset($__componentOriginaleec744ad5116c721f48141438b9836a9); ?>
<?php endif; ?>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    </div>


    
    <div class="lq-world-tile__content">

        <h3 class="lq-world-tile__title">
            <?php echo e($title); ?>

        </h3>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($description): ?>
            <p class="lq-world-tile__description">
                <?php echo e($description); ?>

            </p>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


        
        <div class="mt-5">

            <div class="lq-progress-line">
                <span>Progress</span>

                <span>
                    <?php echo e(number_format($progress)); ?>%
                </span>
            </div>

            <div class="lq-progress">
                <span style="width: <?php echo e($progress); ?>%;"></span>
            </div>

        </div>


        
        <div class="lq-world-tile__footer">

            <?php if (isset($component)) { $__componentOriginaleec744ad5116c721f48141438b9836a9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaleec744ad5116c721f48141438b9836a9 = $attributes; } ?>
<?php $component = App\View\Components\Lq\Badge::resolve(['variant' => 'achievement'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lq.badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Lq\Badge::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

                ⭐ <?php echo e(number_format($xp)); ?> XP
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaleec744ad5116c721f48141438b9836a9)): ?>
<?php $attributes = $__attributesOriginaleec744ad5116c721f48141438b9836a9; ?>
<?php unset($__attributesOriginaleec744ad5116c721f48141438b9836a9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaleec744ad5116c721f48141438b9836a9)): ?>
<?php $component = $__componentOriginaleec744ad5116c721f48141438b9836a9; ?>
<?php unset($__componentOriginaleec744ad5116c721f48141438b9836a9); ?>
<?php endif; ?>


            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($showAction): ?>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($locked): ?>

                    <?php if (isset($component)) { $__componentOriginalffd5753d2d48917a3dd59c1d9ea70fe1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalffd5753d2d48917a3dd59c1d9ea70fe1 = $attributes; } ?>
<?php $component = App\View\Components\Lq\Button::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lq.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Lq\Button::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'secondary','size' => 'sm','disabled' => true]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

                        🔒 Locked
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalffd5753d2d48917a3dd59c1d9ea70fe1)): ?>
<?php $attributes = $__attributesOriginalffd5753d2d48917a3dd59c1d9ea70fe1; ?>
<?php unset($__attributesOriginalffd5753d2d48917a3dd59c1d9ea70fe1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalffd5753d2d48917a3dd59c1d9ea70fe1)): ?>
<?php $component = $__componentOriginalffd5753d2d48917a3dd59c1d9ea70fe1; ?>
<?php unset($__componentOriginalffd5753d2d48917a3dd59c1d9ea70fe1); ?>
<?php endif; ?>

                <?php else: ?>

                    <?php echo e($slot); ?>


                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        </div>

    </div>

</article><?php /**PATH C:\laragon\www\LearnQuest\resources\views/components/lq/world-tile.blade.php ENDPATH**/ ?>