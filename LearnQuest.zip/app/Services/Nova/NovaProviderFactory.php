<?php

namespace App\Services\Nova;

use App\Contracts\Ai\NovaAiProviderContract;
use App\Services\Nova\Providers\AnthropicNovaProvider;
use App\Services\Nova\Providers\DeepSeekNovaProvider;
use App\Services\Nova\Providers\GeminiNovaProvider;
use App\Services\Nova\Providers\MistralNovaProvider;
use App\Services\Nova\Providers\OpenAiNovaProvider;
use App\Services\Nova\Providers\OpenRouterNovaProvider;
use Illuminate\Contracts\Container\Container;
use InvalidArgumentException;

class NovaProviderFactory
{
    /**
     * Map configured provider names to their implementations.
     *
     * @var array<string, class-string<NovaAiProviderContract>>
     */
    protected static array $providers = [
        'anthropic' => AnthropicNovaProvider::class,
        'claude' => AnthropicNovaProvider::class,
        'openai' => OpenAiNovaProvider::class,
        'chatgpt' => OpenAiNovaProvider::class,
        'gemini' => GeminiNovaProvider::class,
        'openrouter' => OpenRouterNovaProvider::class,
        'deepseek' => DeepSeekNovaProvider::class,
        'mistral' => MistralNovaProvider::class,
    ];

    public function __construct(
        protected Container $container,
    ) {}

    public function make(
        ?string $provider = null
    ): NovaAiProviderContract {
        $key = strtolower(
            trim(
                $provider
                    ?? config('learnquest.nova.provider', 'gemini')
            )
        );

        $class = static::$providers[$key] ?? null;

        if (! $class) {
            throw new InvalidArgumentException(
                "Unknown Nova AI provider [{$key}]. Available: "
                .implode(', ', array_keys(static::$providers))
            );
        }

        return $this->container->make($class);
    }
}
