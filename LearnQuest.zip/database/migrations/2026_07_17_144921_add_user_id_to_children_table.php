<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('children', function (Blueprint $table) {

            $table->foreignId('user_id')
                ->nullable(false)
                ->after('id')
                ->constrained('users')
                ->cascadeOnDelete();

        });
    }


    public function down(): void
    {
        Schema::table('children', function (Blueprint $table) {

            $table->dropForeign([
                'user_id'
            ]);

            $table->dropColumn('user_id');

        });
    }
};